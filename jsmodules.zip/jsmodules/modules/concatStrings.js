export function concatStrings(word1, word2) {
  return Первое - "${word1}", второе - "${word2}";
}
