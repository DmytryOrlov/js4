export function calculateAverage(a, b, c) {
  return (a + b + c) / 3;
}
